MTOM attachment processing example.

This application is a server and client to demonstate MTOM attachment handling.

The application runs as a simple CGI server, stand-alone Web server on a port,
or a test client application to test multiple MTOM attachment handling
features.

