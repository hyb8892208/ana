Modules for gSOAP

The modules are released under the gSOAP open source public license, see
license.pdf in the gSOAP root dir of the package.

gsoap_win		IIS and WinInet support
mod_gsoap-0.6		mod_gsoap 0.6 for Apache 1.3 and 2.x

Please visit http://sourceforge.net/projects/mod-gsoap

Refer to the Christian Aberger's Web site for the original intructions
for gsoap_win for IIS: http://mx.aberger.at/SOAP/

