IIS and WinInet modules for gSOAP 

The modules are released under the GPL, the gSOAP open source public license,
or commercial license from Genivia Inc.

The IIS module enables integration of gSOAP services with MS internet
information server (IIS) through ISAPI.

The WinInet module enables a seamless client-side integration of gSOAP client
applications in MS Windows environments.

IMPORTANT: make sure to compile all sources in C++ compilation mode. If you
migrate to a project file .vcproj, please set CompileAs="2" in your .vcproj
file.
