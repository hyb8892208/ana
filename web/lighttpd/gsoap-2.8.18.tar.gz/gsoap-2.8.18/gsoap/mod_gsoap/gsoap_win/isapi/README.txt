IIS module for gSOAP 

The IIS module enables integration of gSOAP services with MS internet
information server (IIS) through ISAPI.

IMPORTANT: make sure to compile all sources in C++ compilation mode. If you
migrate to a project file .vcproj, please set CompileAs="2" in your .vcproj
file.

