//gsoap ns service name:	calc
//gsoap ns service location:	http://localhost/calc
//gsoap ns service namespace:	calc
//gsoap ns schema namespace:	calc
//gsap ns service executable: gsoap
int ns__add(int a, int b, int *result);

