

extern "C" int test() {
    return 10;
}
